package com.cognizant.truyum.authenticationservice.exception;

public class GlobalExceptionHandler {

}
