package com.cognizant.truyum.authenticationservice.exception;

public class UserAlreadyExistsException extends Exception {


	
	
}
