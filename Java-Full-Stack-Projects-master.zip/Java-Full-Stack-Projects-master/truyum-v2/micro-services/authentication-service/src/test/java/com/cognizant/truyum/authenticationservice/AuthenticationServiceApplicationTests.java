package com.cognizant.truyum.authenticationservice;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
