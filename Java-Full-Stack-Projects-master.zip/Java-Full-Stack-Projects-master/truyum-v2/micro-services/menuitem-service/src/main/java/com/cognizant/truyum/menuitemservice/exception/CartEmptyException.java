package com.cognizant.truyum.menuitemservice.exception;

public class CartEmptyException extends Exception {

	

	public CartEmptyException()
	{
		super("Cart is Empty");
	}
	
}
