package com.cognizant.truyum.menuitemservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.truyum.menuitemservice.model.Role;

public interface RoleRepository extends JpaRepository<Role,Integer>{

}
