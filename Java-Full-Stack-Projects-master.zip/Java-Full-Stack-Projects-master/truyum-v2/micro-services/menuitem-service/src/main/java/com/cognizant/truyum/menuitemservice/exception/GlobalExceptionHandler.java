package com.cognizant.truyum.menuitemservice.exception;

public class GlobalExceptionHandler {

}
