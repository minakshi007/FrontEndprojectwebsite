package com.cognizant.truyum.menuitemservice.exception;

public class UserAlreadyExistsException extends Exception {


	
	
}
