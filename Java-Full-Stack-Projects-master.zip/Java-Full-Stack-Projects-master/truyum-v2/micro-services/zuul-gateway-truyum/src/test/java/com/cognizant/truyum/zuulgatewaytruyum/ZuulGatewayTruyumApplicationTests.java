package com.cognizant.truyum.zuulgatewaytruyum;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulGatewayTruyumApplicationTests {

	@Test
	void contextLoads() {
	}

}
