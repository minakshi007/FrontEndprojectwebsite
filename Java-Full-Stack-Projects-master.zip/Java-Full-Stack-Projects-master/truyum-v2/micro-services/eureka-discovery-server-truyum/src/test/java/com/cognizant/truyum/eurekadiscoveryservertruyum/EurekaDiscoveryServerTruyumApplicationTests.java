package com.cognizant.truyum.eurekadiscoveryservertruyum;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaDiscoveryServerTruyumApplicationTests {

	@Test
	void contextLoads() {
	}

}
