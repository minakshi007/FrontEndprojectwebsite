package com.cognizant.truyum.exception;

public class UserAlreadyExistsException extends Exception {


	
	
}
