package com.cognizant.truyum.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.truyum.model.Role;

public interface RoleRepository extends JpaRepository<Role,Integer>{

}
