export interface fooditem
{

id:number,name:string,price:number,active:boolean,date_of_Launch: Date,category:string,free_delivery:boolean,image:string;

}