package com.cognizant.moviecruiser.authenticationservicemoviecruiser.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.moviecruiser.authenticationservicemoviecruiser.model.Role;

public interface RoleRepository extends JpaRepository<Role,Integer>{

}
