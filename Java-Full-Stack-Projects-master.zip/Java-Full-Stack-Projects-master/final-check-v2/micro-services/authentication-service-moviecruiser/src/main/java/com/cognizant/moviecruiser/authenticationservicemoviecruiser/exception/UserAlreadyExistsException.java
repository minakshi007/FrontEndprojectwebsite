package com.cognizant.moviecruiser.authenticationservicemoviecruiser.exception;

public class UserAlreadyExistsException extends Exception {

}
