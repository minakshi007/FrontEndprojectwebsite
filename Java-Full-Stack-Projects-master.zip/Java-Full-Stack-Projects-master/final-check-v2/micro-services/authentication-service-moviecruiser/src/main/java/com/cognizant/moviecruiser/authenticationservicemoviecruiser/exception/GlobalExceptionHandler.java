package com.cognizant.moviecruiser.authenticationservicemoviecruiser.exception;

public class GlobalExceptionHandler {

}
