package com.cognizant.moviecruiser.movieservice.exception;

public class UserAlreadyExistsException extends Exception {

}
