package com.cognizant.moviecruiser.movieservice.exception;

public class GlobalExceptionHandler {

}
