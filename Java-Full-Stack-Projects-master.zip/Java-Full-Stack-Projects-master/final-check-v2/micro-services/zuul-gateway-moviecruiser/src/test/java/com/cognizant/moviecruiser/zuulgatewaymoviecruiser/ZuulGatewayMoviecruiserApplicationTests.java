package com.cognizant.moviecruiser.zuulgatewaymoviecruiser;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulGatewayMoviecruiserApplicationTests {

	@Test
	void contextLoads() {
	}

}
