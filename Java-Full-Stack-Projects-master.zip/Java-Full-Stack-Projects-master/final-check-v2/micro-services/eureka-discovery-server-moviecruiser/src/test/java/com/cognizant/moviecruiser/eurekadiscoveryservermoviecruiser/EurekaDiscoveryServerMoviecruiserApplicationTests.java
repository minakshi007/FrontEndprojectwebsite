package com.cognizant.moviecruiser.eurekadiscoveryservermoviecruiser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaDiscoveryServerMoviecruiserApplicationTests {

	@Test
	void contextLoads() {
	}

}
