//package com.cognizant.moviecruiser.dao;
//
//import com.cognizant.moviecruiser.model.favorites;
//
//public interface FavoritesDao {
//
//	
//	
//	
//	public boolean addFavoritesItem(String userName, long menuItemId);
//
//	public favorites getAllFavoritesItems(String userName);
//
//	public void removeFavoritesItem(String userName, long movieItemId);
//	
//}
