package com.cognizant.moviecruiser.exception;

public class UserAlreadyExistsException extends Exception {

}
