package com.cognizant.moviecruiser.exception;

public class GlobalExceptionHandler {

}
