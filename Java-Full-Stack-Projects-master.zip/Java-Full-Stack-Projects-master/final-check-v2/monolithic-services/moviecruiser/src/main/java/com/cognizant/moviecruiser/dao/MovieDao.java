//package com.cognizant.moviecruiser.dao;
//
//import java.util.List;
//
//import com.cognizant.moviecruiser.model.movie;
//
//public interface MovieDao {
//
//
//	
//	public List<movie> getMovieListAdmin();
//	
//	public List<movie> getMovieListCustomer();
//	public void modifyMovie( movie movie);
//	public movie getMovie( long movieId);
//	
//	
//	
//}
