//package com.cognizant.moviecruiser.model;
//
//import java.util.List;
//
//public class favorites {
//
//	
//	private List<movie> movieList;
//
//	private int nooffavorites;
//
//	public List<movie> getMovieList() {
//		return movieList;
//	}
//
//	public void setMovieList(List<movie> movieList) {
//		this.movieList = movieList;
//	}
//
//	public int getNooffavorites() {
//		return nooffavorites;
//	}
//
//	public void setNooffavorites(int nooffavorites) {
//		this.nooffavorites = nooffavorites;
//	}
//
//	@Override
//	public String toString() {
//		return "favorites [movieList=" + movieList + ", nooffavorites=" + nooffavorites + "]";
//	}
//
//	/**
//	 * @param movieList
//	 * @param nooffavorites
//	 */
//	public favorites(List<movie> movieList, int nooffavorites) {
//		this.movieList = movieList;
//		this.nooffavorites = nooffavorites;
//	}
//
//	/**
//	 * 
//	 */
//	public favorites() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//	
//	
//}
