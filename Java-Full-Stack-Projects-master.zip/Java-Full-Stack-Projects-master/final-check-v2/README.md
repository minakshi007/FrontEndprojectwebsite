Whole Full Stack project using Spring + Angular
