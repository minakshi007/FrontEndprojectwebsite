export interface movie
{

id:number,title:string,box_office:number,active:boolean,date_of_Launch: Date,genre:string,has_teaser:boolean,image:string;

}