export interface User
{


    firstname:string,
    lastname:string,
    username:string,
    password:string
}