import { movie } from "src/app/movie";


export interface favorites
{

    movieList:movie[];
    // name:string,price:number;
    total:number;
}