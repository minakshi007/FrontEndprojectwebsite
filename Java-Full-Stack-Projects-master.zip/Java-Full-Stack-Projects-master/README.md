# Java-Full-Stack-Projects

There are two projects in this : 1) Truyum : Food Ordering Website
                                 2) Moviecruiser : Movie Booking website. 
                                 
                                 
These projects are developed and implemented with following Technologies and Frameworks

Programming Language : JAVA with MySQL

Frameworks : Spring Framework(REST API's) with Hibernate(connection to database)

FrontEND : ANGULAR

Backend  : JAVA + Spring + HIbernate

Database : MySQL 

Full Stack project files are :
## 1)  Moviecruiser : Movie Booking website

link here=> https://github.com/balajisomasale/Java-Full-Stack-Projects/tree/master/final-check-v2

## 2) Truyum : Food Ordering Website 

link here => https://github.com/balajisomasale/Java-Full-Stack-Projects/tree/master/truyum-v2
