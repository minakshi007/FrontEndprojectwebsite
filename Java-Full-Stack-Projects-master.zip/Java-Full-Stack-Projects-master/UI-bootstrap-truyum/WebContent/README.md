This is the Basic Java project with CSS and JS
